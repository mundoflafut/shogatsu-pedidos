Projeto modelo. Substitua pelos arquivos reais do sistema.
